import { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MotionConfig } from "framer-motion";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";

import { ROUTE_PATHS } from "@/lib/index";
import Home from "@/pages/Home";
import Pricing from "@/pages/Pricing";
import About from "@/pages/About";
import Dashboard from "@/pages/Dashboard";
import Templates from "@/pages/Templates";
import MyBoards from "@/pages/MyBoards";
import Team from "@/pages/Team";
import Analytics from "@/pages/Analytics";
import Settings from "@/pages/Settings";
import Profile from "@/pages/Profile";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 1,
    },
  },
});

const App = () => {
  useEffect(() => {
    document.documentElement.dir = "rtl";
    document.documentElement.lang = "ar";
    document.title = "كيان بورد | KayanBoard - AI SaaS Dashboard Builder";
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <MotionConfig reducedMotion="user">
          <div className="min-h-screen bg-background font-sans antialiased selection:bg-primary/20 selection:text-primary">
            <BrowserRouter>
              <Routes>
                <Route 
                  path={ROUTE_PATHS.HOME} 
                  element={<Home />} 
                />
                <Route 
                  path={ROUTE_PATHS.PRICING} 
                  element={<Pricing />} 
                />
                <Route 
                  path={ROUTE_PATHS.ABOUT} 
                  element={<About />} 
                />
                <Route 
                  path={ROUTE_PATHS.DASHBOARD} 
                  element={<Dashboard />} 
                />
                <Route 
                  path={ROUTE_PATHS.TEMPLATES} 
                  element={<Templates />} 
                />
                <Route 
                  path={ROUTE_PATHS.MY_BOARDS} 
                  element={<MyBoards />} 
                />
                <Route 
                  path={ROUTE_PATHS.TEAM} 
                  element={<Team />} 
                />
                <Route 
                  path={ROUTE_PATHS.ANALYTICS} 
                  element={<Analytics />} 
                />
                <Route 
                  path={ROUTE_PATHS.SETTINGS} 
                  element={<Settings />} 
                />
                <Route 
                  path={ROUTE_PATHS.PROFILE} 
                  element={<Profile />} 
                />
                
                <Route 
                  path="*" 
                  element={<Navigate to={ROUTE_PATHS.HOME} replace />} 
                />
              </Routes>
            </BrowserRouter>
            
            <Toaster />
            <Sonner 
              position="top-center" 
              expand={false} 
              richColors 
              closeButton
              theme="light"
            />
          </div>
        </MotionConfig>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;