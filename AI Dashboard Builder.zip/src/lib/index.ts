export const ROUTE_PATHS = {
  HOME: '/',
  PRICING: '/pricing',
  ABOUT: '/about',
  DASHBOARD: '/dashboard',
  MY_BOARDS: '/my-boards',
  TEMPLATES: '/templates',
  TEAM: '/team',
  ANALYTICS: '/analytics',
  SETTINGS: '/settings',
  PROFILE: '/profile',
} as const;

export type WidgetType = 'kpi' | 'line' | 'bar' | 'pie' | 'activity';

export interface DashboardWidget {
  id: string;
  type: WidgetType;
  title: string;
  value?: string | number;
  trend?: 'up' | 'down' | 'neutral';
  change?: string;
  data?: any[];
  description?: string;
  config?: {
    colors?: string[];
    showGrid?: boolean;
    dataKeys?: string[];
  };
}

export interface DashboardTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  preview: string;
  widgets: DashboardWidget[];
  color: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: string;
  company: string;
  joinDate: string;
  plan: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  priceMonthly: number;
  priceYearly: number;
  description: string;
  features: string[];
  isFeatured?: boolean;
  buttonText: string;
}

export const ARABIC_CONTENT = {
  common: {
    appName: 'كيان بورد',
    getStarted: 'ابدأ الآن',
    learnMore: 'تعرف على المزيد',
    dashboard: 'لوحة التحكم',
    pricing: 'الأسعار',
    about: 'من نحن',
    contact: 'اتصل بنا',
    rights: '© 2026 كيان بورد. جميع الحقوق محفوظة.',
  },
  hero: {
    title: 'بناء لوحات تحكم ذكية.. بسرعة الضوء',
    subtitle: 'حوّل أفكارك إلى لوحات بيانات تفاعلية مدعومة بالذكاء الاصطناعي في ثوانٍ معدودة.',
    cta: 'ابدأ البناء مجاناً',
  },
  features: {
    title: 'لماذا تختار كيان بورد؟',
    subtitle: 'نحن نوفر لك الأدوات اللازمة للنمو والتحليل الذكي.',
    items: [
      {
        title: 'تصميم واجهة عصري',
        description: 'واجهات مستخدم مذهلة تعتمد على مبادئ التصميم الحديثة وتدعم العربية بشكل كامل.',
      },
      {
        title: 'تحليلات ذكية',
        description: 'احصل على رؤى عميقة من بياناتك باستخدام تقنيات الذكاء الاصطناعي المتقدمة.',
      },
      {
        title: 'تكامل سلس',
        description: 'اربط بياناتك من مختلف المصادر بسهولة ويسر في مكان واحد.',
      },
      {
        title: 'تخصيص كامل',
        description: 'تحكم في كل تفاصيل لوحة التحكم الخاصة بك لتناسب هويتك التجارية.',
      },
    ],
  },
  pricing: {
    title: 'خطط تناسب الجميع',
    subtitle: 'اختر الخطة المثالية لاحتياجاتك، سواء كنت فرداً أو مؤسسة.',
    monthly: 'شهرياً',
    yearly: 'سنوياً',
    save: 'وفر 20%',
  },
  about: {
    visionTitle: 'رؤيتنا',
    visionText: 'أن نكون المنصة الرائدة عالمياً في تمكين الشركات من فهم بياناتها من خلال حلول ذكاء اصطناعي بديهية وجميلة.',
    missionTitle: 'رسالتنا',
    missionText: 'تبسيط عملية بناء لوحات التحكم المعقدة وجعل تحليل البيانات متاحاً للجميع دون الحاجة لخبرة برمجية.',
    teamTitle: 'فريقنا المبدع',
  },
  dashboard: {
    aiMagic: '✨ سحر الذكاء الاصطناعي',
    generate: 'توليد لوحة تحكم',
    placeholder: 'صف مشروعك (مثال: لوحة تحكم لعيادة طبية)...',
    generating: 'جاري توليد لوحتك الذكية...',
    myBoards: 'لوحاتي',
    templates: 'القوالب',
    team: 'الفريق',
    settings: 'الإعدادات',
    analytics: 'التحليلات',
    recentActivity: 'النشاط الأخير',
    useTemplate: 'استخدم القالب',
    viewAll: 'عرض الكل',
    createNew: 'إنشاء جديد',
  },
  templates: {
    title: 'قوالب جاهزة',
    subtitle: 'ابدأ بسرعة باستخدام قوالبنا المصممة مسبقاً',
    categories: {
      all: 'الكل',
      sales: 'المبيعات',
      marketing: 'التسويق',
      finance: 'المالية',
      hr: 'الموارد البشرية',
      operations: 'العمليات',
    },
  },
  profile: {
    title: 'الملف الشخصي',
    editProfile: 'تعديل الملف الشخصي',
    personalInfo: 'المعلومات الشخصية',
    accountSettings: 'إعدادات الحساب',
    notifications: 'الإشعارات',
    security: 'الأمان',
    billing: 'الفواتير',
    logout: 'تسجيل الخروج',
  },
  myBoards: {
    title: 'لوحاتي',
    subtitle: 'إدارة جميع لوحات التحكم الخاصة بك',
    createBoard: 'إنشاء لوحة جديدة',
    lastModified: 'آخر تعديل',
    views: 'المشاهدات',
  },
  team: {
    title: 'الفريق',
    subtitle: 'إدارة أعضاء الفريق والصلاحيات',
    inviteMember: 'دعوة عضو جديد',
    members: 'الأعضاء',
    pending: 'في الانتظار',
  },
  analytics: {
    title: 'التحليلات',
    subtitle: 'تحليل شامل لأداء لوحات التحكم',
    overview: 'نظرة عامة',
    performance: 'الأداء',
    usage: 'الاستخدام',
  },
  settings: {
    title: 'الإعدادات',
    subtitle: 'تخصيص تفضيلاتك وإعدادات الحساب',
    general: 'عام',
    appearance: 'المظهر',
    notifications: 'الإشعارات',
    integrations: 'التكاملات',
  },
} as const;

export function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('ar-SA', {
    style: 'currency',
    currency: 'SAR',
    maximumFractionDigits: 0,
  }).format(amount);
};
